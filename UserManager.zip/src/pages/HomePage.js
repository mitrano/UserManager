import React from 'react';
import Navbar from '../components/Navbar';

const HomePage = () => (
  <div>
    <Navbar />
    <h1>Bem vindo ao sistema de Gestão de Usuários</h1>
  </div>
);

export default HomePage;
